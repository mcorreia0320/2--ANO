package org.example;

public class AzureProperities {

    public static String DEVICEID = "mydevice2019122";

    public static String TELEMETRY_ID = "TelemetryReader";

    public static String INVOKE_ID = "MethodInvoke";
    public static String INVOKE_CONN = "HostName=iothub2019122.azure-devices.net;DeviceId=mydevice2019122;ModuleId=MethodInvoke;SharedAccessKey=/EiqHIGl34xefN0ktE8Ef2YcpOEAFN5OvAIoTL66XNY=";
    public static  String DEVICE = "HostName=iothub2019122.azure-devices.net;DeviceId=mydevice2019122;SharedAccessKey=tTQ4DK8nVzyG0KDJBY6ZPINswKdmmfqjiAIoTPeKZ8o=";

    public static  String OWNER = "HostName=iothub2019122.azure-devices.net;SharedAccessKeyName=iothubowner;SharedAccessKey=cXAyOi4B+0OOBNNvTfXFvua5A+W2sBV5HAIoTGSIMV0=";

    public static String TELEMETRY_MODULE = "HostName=iothub2019122.azure-devices.net;DeviceId=mydevice2019122;ModuleId=TelemetryReader;SharedAccessKey=uXBc6apU86dRKrMjjLOezUr1sQ6M7bSTlAIoTEe9T0M=";


}
